
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AspectRatio, Resolution, GeneratedImage } from './types';
import { generateCinematicImage } from './services/geminiService';
import MindMap from './components/MindMap';

const App: React.FC = () => {
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [ratio, setRatio] = useState<AspectRatio>("16:9");
  const [res, setRes] = useState<Resolution>("1k");
  const [showInspiration, setShowInspiration] = useState(false);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null);

  const ITEMS_PER_PAGE = 20;

  const handleGenerate = async (selectedLabels: string[]) => {
    if (loading) return;
    setLoading(true);
    // 将灵感标签数组转换为描述性 Prompt
    const promptString = selectedLabels.join(", ");
    const imageUrl = await generateCinematicImage(promptString, ratio);
    if (imageUrl) {
      const newImage: GeneratedImage = {
        id: Math.random().toString(36).substr(2, 9),
        url: imageUrl,
        timestamp: Date.now(),
        prompt: promptString,
        config: { ratio, resolution: res }
      };
      setImages(prev => [newImage, ...prev]);
    }
    setLoading(false);
  };

  const handleMindMapComplete = (selectedLabels: string[]) => {
    setShowInspiration(false);
    handleGenerate(selectedLabels);
  };

  const totalPages = Math.ceil(images.length / ITEMS_PER_PAGE);
  const paginatedImages = images.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  return (
    <div className="flex h-screen w-screen overflow-hidden text-[#1d1d1f] bg-transparent">
      
      {/* 左侧控制区 (2/5) */}
      <aside className="w-[40%] h-full flex flex-col p-14 glass-panel border-r border-black/5 relative z-10 bg-white/60">
        <header className="mb-20">
          <motion.h1 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-7xl font-extralight tracking-tighter"
          >
            Cine<span className="font-semibold text-blue-600">Mind</span>
          </motion.h1>
          <div className="h-px w-20 bg-blue-600/30 mt-6" />
          <p className="text-black/30 mt-6 text-[10px] font-bold uppercase tracking-[0.5em] leading-relaxed">
            AI 电影构图辅助系统<br/>Professional Cinematography
          </p>
        </header>

        <div className="flex-1 space-y-20 flex flex-col justify-start overflow-y-auto custom-scrollbar pr-4">
          {/* 灵感按键 */}
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <button 
              onClick={() => setShowInspiration(true)}
              className="w-full py-16 px-10 bg-white rounded-[3.5rem] border border-black/5 hover:border-blue-500/40 transition-all group flex flex-col items-center gap-8 shadow-2xl shadow-gray-200/50"
            >
              <div className="w-24 h-24 rounded-full bg-blue-600/5 flex items-center justify-center group-hover:bg-blue-600/10 transition-all">
                <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <div className="text-center">
                <span className="text-3xl font-light tracking-[0.2em] block">灵感触发</span>
                <span className="text-[10px] text-black/20 font-black mt-3 uppercase tracking-widest">Constructing Visual Galaxy</span>
              </div>
            </button>
          </motion.div>

          {/* 参数设置区 */}
          <div className="space-y-16">
            <div className="space-y-8">
              <label className="text-[10px] font-black text-black/30 uppercase tracking-[0.4em] flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-blue-500/30" />
                图像比例 / Aspect Ratio
              </label>
              <div className="grid grid-cols-4 gap-3 bg-black/5 p-1.5 rounded-[1.5rem] border border-black/5">
                {(["16:9", "4:3", "2.35:1", "1:1"] as AspectRatio[]).map(r => (
                  <button
                    key={r}
                    onClick={() => setRatio(r)}
                    className={`py-4 rounded-[1.2rem] text-xs font-bold transition-all ${ratio === r ? 'bg-white text-blue-600 shadow-xl' : 'text-black/30 hover:text-black/50'}`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-8">
              <label className="text-[10px] font-black text-black/30 uppercase tracking-[0.4em] flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-blue-500/30" />
                分辨率 / Resolution
              </label>
              <div className="flex gap-3">
                {(["480p", "720p", "1k", "2k"] as Resolution[]).map(r => (
                  <button
                    key={r}
                    onClick={() => setRes(r)}
                    className={`flex-1 py-5 rounded-[1.5rem] text-[10px] font-black border transition-all ${res === r ? 'bg-blue-600/5 border-blue-500/20 text-blue-600 shadow-md' : 'bg-black/5 border-transparent text-black/20 hover:bg-black/10'}`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <footer className="mt-auto pt-10 flex flex-col items-center opacity-10">
          <span className="text-[9px] font-black uppercase tracking-[0.8em]">CineMind Lab v3.0</span>
          <div className="w-2 h-2 rounded-full bg-black mt-4" />
        </footer>
      </aside>

      {/* 右侧展示区 (3/5) */}
      <main className="w-[60%] h-full flex flex-col overflow-hidden relative bg-gray-50/50 backdrop-blur-sm">
        <AnimatePresence>
          {loading && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-white/80 backdrop-blur-3xl"
            >
              <div className="w-20 h-20 border-[3px] border-blue-600/10 border-t-blue-600 rounded-full animate-spin" />
              <p className="mt-10 text-[10px] font-black tracking-[0.6em] text-blue-600/60 uppercase">冲洗画面中 / Rendering Frame</p>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex-1 p-16 overflow-y-auto custom-scrollbar">
          <div className="flex justify-between items-end mb-20">
            <div className="space-y-4">
              <h2 className="text-5xl font-extralight tracking-tighter">作品库</h2>
              <div className="flex items-center gap-3">
                <div className="w-8 h-[2px] bg-blue-600/20" />
                <p className="text-black/20 text-[10px] uppercase tracking-[0.3em] font-bold">Chronological Composition Gallery</p>
              </div>
            </div>
          </div>

          {images.length === 0 ? (
            <div className="h-[60vh] flex flex-col items-center justify-center opacity-[0.03]">
              <svg className="w-48 h-48 mb-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={0.3} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <p className="text-xl tracking-[1em] uppercase font-black">库内暂无画面</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
              <AnimatePresence mode="popLayout">
                {paginatedImages.map((img) => (
                  <motion.div
                    key={img.id}
                    layout
                    initial={{ scale: 0.95, opacity: 0, y: 20 }}
                    animate={{ scale: 1, opacity: 1, y: 0 }}
                    onClick={() => setSelectedImage(img)}
                    className="group relative rounded-[3.5rem] overflow-hidden bg-white shadow-[0_30px_80px_rgba(0,0,0,0.06)] transition-all border border-black/[0.03] hover:shadow-[0_40px_100px_rgba(0,113,227,0.1)] cursor-zoom-in"
                  >
                    <div className="relative aspect-video overflow-hidden">
                      <img 
                        src={img.url} 
                        alt="Generated frame"
                        className="w-full h-full object-cover transition-transform duration-[2000ms] group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-700 p-12 flex flex-col justify-end">
                        <div className="flex justify-between items-center border-t border-white/10 pt-8">
                          <span className="text-[10px] text-white/40 font-black uppercase tracking-widest">{new Date(img.timestamp).toLocaleTimeString()}</span>
                          <span className="px-5 py-2 bg-white/10 backdrop-blur-md rounded-full text-[10px] text-white font-black">{img.config.ratio}</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}

          {/* 分页按钮 */}
          {totalPages > 1 && (
            <div className="mt-24 flex justify-center items-center gap-12 pb-20">
              <button 
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(p => p - 1)}
                className="p-6 bg-white shadow-xl rounded-full hover:bg-gray-50 disabled:opacity-30 transition-all border border-black/5"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 19l-7-7 7-7" /></svg>
              </button>
              <div className="text-[11px] font-black text-black/20 uppercase tracking-[0.8em]">
                P. {currentPage} <span className="text-black/5 mx-6">/</span> {totalPages}
              </div>
              <button 
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(p => p + 1)}
                className="p-6 bg-white shadow-xl rounded-full hover:bg-gray-50 disabled:opacity-30 transition-all border border-black/5"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5l7 7-7 7" /></svg>
              </button>
            </div>
          )}
        </div>
      </main>

      {/* 灵感思维导图 */}
      <AnimatePresence>
        {showInspiration && (
          <MindMap 
            onSelectionComplete={handleMindMapComplete} 
            onClose={() => setShowInspiration(false)} 
          />
        )}
      </AnimatePresence>

      {/* 全屏大图查看 */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImage(null)}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-10 cursor-zoom-out"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-[90vw] max-h-[90vh] shadow-2xl rounded-3xl overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <img src={selectedImage.url} alt="Full screen" className="object-contain max-h-[85vh] w-auto shadow-2xl" />
              <div className="absolute top-8 right-8">
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="w-12 h-12 bg-white/10 hover:bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center text-white transition-all"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2}/></svg>
                </button>
              </div>
              <div className="p-10 bg-gradient-to-t from-black/50 to-transparent absolute bottom-0 left-0 right-0 text-white">
                 <p className="text-sm font-light opacity-80 mb-2">构图详情 / Frame Details</p>
                 <div className="flex gap-4 items-center">
                    <span className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-bold uppercase tracking-widest">{selectedImage.config.ratio}</span>
                    <span className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-bold uppercase tracking-widest">{selectedImage.config.resolution}</span>
                 </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
